    @extends('layouts.app')

    @section('content')

    @include('layouts.buku.laporan.index')

    @endsection